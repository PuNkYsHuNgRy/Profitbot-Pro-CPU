# Profitbot-Pro-CPU
CPU only version of Profitbot Pro. Able to be run side-by-side with the main Profotbot Pro.
